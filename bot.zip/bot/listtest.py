import yt_dlp

def print_playlist_videos(playlist_url):
    ydl_opts = {
        'quiet': True,
        'extract_flat': True,  # Extract metadata without downloading
    }

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        try:
            info_dict = ydl.extract_info(playlist_url, download=False)
            print(f'URL-e filmów w playliście: {info_dict.get("title", "Unknown Playlist Title")}')
            
            for entry in info_dict['entries']:
                print(entry.get('url', 'Unknown URL'))
        except Exception as e:
            print(f'Błąd: {e}')

if __name__ == "__main__":
    playlist_url = "https://www.youtube.com/watch?v=K-PdbfkA7LM&list=RDK-PdbfkA7LM&start_radio=1"
    print_playlist_videos(playlist_url)

